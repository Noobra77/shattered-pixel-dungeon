package com.shatteredpixel.shatteredpixeldungeon.items.food;

import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.effects.Speck;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class EagleEyeFruit extends Food {

	{
		image = ItemSpriteSheet.BERRY;
		energy = 0.0f;
	}

	@Override
	protected void satisfy(Hero hero) {
		if (energy > 0) {
			super.satisfy(hero);
		}
		Buff.prolong(hero, Awareness.class, 20f); Buff.prolong(hero, Foresight.class, 20f); 
	}

	@Override
	public int value() {
		return 15 * quantity;
	}
}
