package com.shatteredpixel.shatteredpixeldungeon.items.tomes;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.items.Gold;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfTeleportation;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class CurseTome extends Tome {

	{
		image = ItemSpriteSheet.SCROLL_NAUDIZ;
	}

	@Override
	protected void effect(Hero hero) {
		debuffAll(Vulnerable.class, 20f); debuffAll(Hex.class, 12f);
	}
}
