package com.shatteredpixel.shatteredpixeldungeon.items.tomes;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.items.Gold;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfTeleportation;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class FortuneTome extends Tome {

	{
		image = ItemSpriteSheet.SCROLL_SOWILO;
	}

	@Override
	protected void effect(Hero hero) {
		new Gold(150 + 40 * Dungeon.depth).doPickUp(hero, hero.pos);
	}
}
