package com.shatteredpixel.shatteredpixeldungeon.items.tomes;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.items.Gold;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfTeleportation;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class MiracleTome extends Tome {

	{
		image = ItemSpriteSheet.SCROLL_TIWAZ;
	}

	@Override
	protected void effect(Hero hero) {
		healSelf(hero, 100); cleanse(hero); Buff.prolong(hero, Bless.class, 40f); Buff.affect(hero, Barrier.class).setShield(15 + hero.HT / 2);
	}
}
