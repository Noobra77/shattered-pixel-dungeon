package com.shatteredpixel.shatteredpixeldungeon.items.tomes;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.items.Gold;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfTeleportation;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class SeerTome extends Tome {

	{
		image = ItemSpriteSheet.SCROLL_YNGVI;
	}

	@Override
	protected void effect(Hero hero) {
		Buff.prolong(hero, MindVision.class, 40f);
	}
}
