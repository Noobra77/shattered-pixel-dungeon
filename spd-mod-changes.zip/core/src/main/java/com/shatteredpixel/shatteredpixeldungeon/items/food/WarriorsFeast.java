package com.shatteredpixel.shatteredpixeldungeon.items.food;

import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.effects.Speck;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class WarriorsFeast extends Food {

	{
		image = ItemSpriteSheet.SUPPLY_RATION;
		energy = 400.0f;
	}

	@Override
	protected void satisfy(Hero hero) {
		if (energy > 0) {
			super.satisfy(hero);
		}
		{ int h = Math.round(hero.HT * 50/100f); hero.HP = Math.min(hero.HT, hero.HP + h); hero.sprite.emitter().burst(Speck.factory(Speck.HEALING), 2); } Buff.prolong(hero, Bless.class, 30f); Buff.prolong(hero, Adrenaline.class, 10f); 
	}

	@Override
	public int value() {
		return 15 * quantity;
	}
}
