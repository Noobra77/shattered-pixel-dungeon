package com.shatteredpixel.shatteredpixeldungeon.items.tomes;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.items.Gold;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfTeleportation;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class GuardianTome extends Tome {

	{
		image = ItemSpriteSheet.SCROLL_YNGVI;
	}

	@Override
	protected void effect(Hero hero) {
		Buff.affect(hero, Barrier.class).setShield(20 + hero.HT / 2); Buff.affect(hero, Barkskin.class).set(3 + hero.lvl, 20);
	}
}
