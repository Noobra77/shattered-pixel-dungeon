package com.shatteredpixel.shatteredpixeldungeon.items.food;

import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.effects.Speck;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class EnergyBar extends Food {

	{
		image = ItemSpriteSheet.PASTY;
		energy = 120.0f;
	}

	@Override
	protected void satisfy(Hero hero) {
		if (energy > 0) {
			super.satisfy(hero);
		}
		Buff.prolong(hero, Stamina.class, 15f); Buff.prolong(hero, Recharging.class, 20f); 
	}

	@Override
	public int value() {
		return 15 * quantity;
	}
}
