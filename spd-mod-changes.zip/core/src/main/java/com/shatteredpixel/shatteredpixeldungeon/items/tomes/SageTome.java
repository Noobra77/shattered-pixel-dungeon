package com.shatteredpixel.shatteredpixeldungeon.items.tomes;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.items.Gold;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfTeleportation;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class SageTome extends Tome {

	{
		image = ItemSpriteSheet.SCROLL_GYFU;
	}

	@Override
	protected void effect(Hero hero) {
		Buff.prolong(hero, Awareness.class, 40f); Buff.prolong(hero, Foresight.class, 40f);
	}
}
