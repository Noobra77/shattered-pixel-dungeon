package com.shatteredpixel.shatteredpixeldungeon.items.food;

import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.effects.Speck;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class StrengthStew extends Food {

	{
		image = ItemSpriteSheet.STEWED;
		energy = 150.0f;
	}

	@Override
	protected void satisfy(Hero hero) {
		if (energy > 0) {
			super.satisfy(hero);
		}
		Buff.detach(hero, Weakness.class); Buff.detach(hero, Vulnerable.class); Buff.detach(hero, Hex.class); Buff.detach(hero, Degrade.class); Buff.prolong(hero, Bless.class, 30f); 
	}

	@Override
	public int value() {
		return 15 * quantity;
	}
}
