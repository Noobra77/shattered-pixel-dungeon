package com.shatteredpixel.shatteredpixeldungeon.items.food;

import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.effects.Speck;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class StoneskinFruit extends Food {

	{
		image = ItemSpriteSheet.BERRY;
		energy = 40.0f;
	}

	@Override
	protected void satisfy(Hero hero) {
		if (energy > 0) {
			super.satisfy(hero);
		}
		Buff.affect(hero, Barkskin.class).set(3 + hero.lvl / 2, 15); 
	}

	@Override
	public int value() {
		return 15 * quantity;
	}
}
