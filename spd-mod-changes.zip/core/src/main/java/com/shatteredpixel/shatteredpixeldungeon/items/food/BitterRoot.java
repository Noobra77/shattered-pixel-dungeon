package com.shatteredpixel.shatteredpixeldungeon.items.food;

import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.effects.Speck;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class BitterRoot extends Food {

	{
		image = ItemSpriteSheet.BERRY;
		energy = 20.0f;
	}

	@Override
	protected void satisfy(Hero hero) {
		if (energy > 0) {
			super.satisfy(hero);
		}
		Buff.detach(hero, Poison.class); 
	}

	@Override
	public int value() {
		return 15 * quantity;
	}
}
