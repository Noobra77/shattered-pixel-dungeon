package com.shatteredpixel.shatteredpixeldungeon.items.food;

import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.effects.Speck;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class SunHoney extends Food {

	{
		image = ItemSpriteSheet.STEWED;
		energy = 100.0f;
	}

	@Override
	protected void satisfy(Hero hero) {
		if (energy > 0) {
			super.satisfy(hero);
		}
		{ int h = Math.round(hero.HT * 50/100f); hero.HP = Math.min(hero.HT, hero.HP + h); hero.sprite.emitter().burst(Speck.factory(Speck.HEALING), 2); } Buff.prolong(hero, Light.class, 100f); 
	}

	@Override
	public int value() {
		return 15 * quantity;
	}
}
