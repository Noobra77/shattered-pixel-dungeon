package com.shatteredpixel.shatteredpixeldungeon.items.food;

import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.effects.Speck;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class GuardianBread extends Food {

	{
		image = ItemSpriteSheet.RATION;
		energy = 100.0f;
	}

	@Override
	protected void satisfy(Hero hero) {
		if (energy > 0) {
			super.satisfy(hero);
		}
		Buff.affect(hero, Barrier.class).setShield(5 + hero.HT / 5); 
	}

	@Override
	public int value() {
		return 15 * quantity;
	}
}
