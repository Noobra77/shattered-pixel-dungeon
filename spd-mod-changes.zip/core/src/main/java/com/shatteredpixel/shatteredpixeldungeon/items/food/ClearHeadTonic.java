package com.shatteredpixel.shatteredpixeldungeon.items.food;

import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.effects.Speck;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class ClearHeadTonic extends Food {

	{
		image = ItemSpriteSheet.BERRY;
		energy = 0.0f;
	}

	@Override
	protected void satisfy(Hero hero) {
		if (energy > 0) {
			super.satisfy(hero);
		}
		Buff.detach(hero, Blindness.class); Buff.detach(hero, Vertigo.class); Buff.detach(hero, Drowsy.class); Buff.detach(hero, Daze.class); Buff.detach(hero, Charm.class); Buff.detach(hero, Terror.class); Buff.detach(hero, Amok.class); 
	}

	@Override
	public int value() {
		return 15 * quantity;
	}
}
