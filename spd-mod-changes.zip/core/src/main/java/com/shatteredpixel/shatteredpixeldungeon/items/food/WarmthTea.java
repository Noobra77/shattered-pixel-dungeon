package com.shatteredpixel.shatteredpixeldungeon.items.food;

import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.effects.Speck;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class WarmthTea extends Food {

	{
		image = ItemSpriteSheet.STEWED;
		energy = 60.0f;
	}

	@Override
	protected void satisfy(Hero hero) {
		if (energy > 0) {
			super.satisfy(hero);
		}
		Buff.detach(hero, Slow.class); Buff.detach(hero, Chill.class); Buff.detach(hero, Cripple.class); Buff.detach(hero, Roots.class); Buff.detach(hero, Frost.class); { int h = Math.round(hero.HT * 15/100f); hero.HP = Math.min(hero.HT, hero.HP + h); hero.sprite.emitter().burst(Speck.factory(Speck.HEALING), 2); } 
	}

	@Override
	public int value() {
		return 15 * quantity;
	}
}
