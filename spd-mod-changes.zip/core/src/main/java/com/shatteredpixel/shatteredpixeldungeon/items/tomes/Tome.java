package com.shatteredpixel.shatteredpixeldungeon.items.tomes;

import com.shatteredpixel.shatteredpixeldungeon.Assets;
import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Mob;
import com.shatteredpixel.shatteredpixeldungeon.items.Item;
import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.sprites.HeroSprite;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.watabou.noosa.audio.Sample;
import com.watabou.utils.Random;

import java.util.ArrayList;

public abstract class Tome extends Item {

	public static final String AC_READ = "READ";

	{
		defaultAction = AC_READ;
		stackable = true;
	}

	@Override
	public ArrayList<String> actions(Hero hero) {
		ArrayList<String> actions = super.actions(hero);
		actions.add(AC_READ);
		return actions;
	}

	@Override
	public void execute(Hero hero, String action) {
		super.execute(hero, action);
		if (action.equals(AC_READ)) {
			if (hero.buff(MagicImmune.class) != null) {
				GLog.w("Your magic is blocked.");
			} else if (hero.buff(Blindness.class) != null) {
				GLog.w("You cannot read while blind.");
			} else {
				detach(hero.belongings.backpack);
				Invisibility.dispel();
				hero.spend(1f);
				hero.busy();
				((HeroSprite) hero.sprite).read();
				Sample.INSTANCE.play(Assets.Sounds.READ);
				effect(hero);
			}
		}
	}

	protected abstract void effect(Hero hero);

	protected static ArrayList<Mob> visibleEnemies() {
		ArrayList<Mob> list = new ArrayList<>();
		for (Mob m : Dungeon.level.mobs.toArray(new Mob[0])) {
			if (m.alignment == Char.Alignment.ENEMY && Dungeon.level.heroFOV[m.pos]) {
				list.add(m);
			}
		}
		return list;
	}

	protected static void damageAll(Hero hero, float mult) {
		for (Mob m : visibleEnemies()) {
			int dmg = Math.round(mult * Random.NormalIntRange(4 + Dungeon.depth * 2, 8 + Dungeon.depth * 3));
			m.damage(Math.max(1, dmg), hero);
		}
	}

	protected static void debuffAll(Class<? extends FlavourBuff> cls, float duration) {
		for (Mob m : visibleEnemies()) {
			if (m.isAlive()) Buff.prolong(m, cls, duration);
		}
	}

	protected static void burnAll() {
		for (Mob m : visibleEnemies()) {
			if (m.isAlive()) Buff.affect(m, Burning.class).reignite(m, 5f);
		}
	}

	protected static void poisonAll(float amount) {
		for (Mob m : visibleEnemies()) {
			if (m.isAlive()) Buff.affect(m, Poison.class).set(amount);
		}
	}

	protected static void bleedAll(float amount) {
		for (Mob m : visibleEnemies()) {
			if (m.isAlive()) Buff.affect(m, Bleeding.class).set(amount);
		}
	}

	protected static void sleepAll() {
		for (Mob m : visibleEnemies()) {
			if (m.isAlive()) Buff.affect(m, MagicalSleep.class);
		}
	}

	protected static void healSelf(Hero hero, int pct) {
		int h = Math.round(hero.HT * pct / 100f);
		hey.HP = Math.min(hero.HT, hero.HP + h);
	}

	protected static void cleanse(Hero hero) {
		Class<?>[] bad = new Class<?>[]{Poison.class, Bleeding.class, Burning.class, Slow.class,
				Chill.class, Cripple.class, Roots.class, Frost.class, Weakness.class, Vulnerable.class,
				Hex.class, Degrade.class, Blindness.class, Vertigo.class, Drowsy.class, Daze.class,
				Charm.class, Terror.class, Amok.class};
		for (Class<?> c : bad) {
			Buff b = hero.buff((Class<? extends Buff>) c);
			if (b != null) b.detach();
		}
	}

	@Override
	public boolean isUpgradable() {
		return false;
	}

	@Override
	public boolean isIdentified() {
		return true;
	}

	@Override
	public int value() {
		return 30 * quantity;
	}
}
