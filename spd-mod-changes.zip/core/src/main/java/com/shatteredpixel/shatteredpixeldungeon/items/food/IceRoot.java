package com.shatteredpixel.shatteredpixeldungeon.items.food;

import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.effects.Speck;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class IceRoot extends Food {

	{
		image = ItemSpriteSheet.BERRY;
		energy = 0.0f;
	}

	@Override
	protected void satisfy(Hero hero) {
		if (energy > 0) {
			super.satisfy(hero);
		}
		Buff.detach(hero, Burning.class); Buff.detach(hero, Slow.class); Buff.detach(hero, Chill.class); Buff.detach(hero, Cripple.class); Buff.detach(hero, Roots.class); Buff.detach(hero, Frost.class); 
	}

	@Override
	public int value() {
		return 15 * quantity;
	}
}
