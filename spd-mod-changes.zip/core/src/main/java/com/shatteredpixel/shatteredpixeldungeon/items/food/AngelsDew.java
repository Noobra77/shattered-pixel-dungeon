package com.shatteredpixel.shatteredpixeldungeon.items.food;

import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.effects.Speck;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

public class AngelsDew extends Food {

	{
		image = ItemSpriteSheet.BERRY;
		energy = 0.0f;
	}

	@Override
	protected void satisfy(Hero hero) {
		if (energy > 0) {
			super.satisfy(hero);
		}
		{ int h = Math.round(hero.HT * 100/100f); hero.HP = Math.min(hero.HT, hero.HP + h); hero.sprite.emitter().burst(Speck.factory(Speck.HEALING), 2); } Buff.detach(hero, Poison.class); Buff.detach(hero, Bleeding.class); Buff.detach(hero, Burning.class); Buff.detach(hero, Slow.class); Buff.detach(hero, Chill.class); Buff.detach(hero, Cripple.class); Buff.detach(hero, Roots.class); Buff.detach(hero, Frost.class); Buff.detach(hero, Weakness.class); Buff.detach(hero, Vulnerable.class); Buff.detach(hero, Hex.class); Buff.detach(hero, Degrade.class); Buff.detach(hero, Blindness.class); Buff.detach(hero, Vertigo.class); Buff.detach(hero, Drowsy.class); Buff.detach(hero, Daze.class); Buff.detach(hero, Charm.class); Buff.detach(hero, Terror.class); Buff.detach(hero, Amok.class); 
	}

	@Override
	public int value() {
		return 15 * quantity;
	}
}
